----[06 Jul 2002]----------------------

Here is another M6809 disassembler :-)

I have written this 'emulation oriented' disassembler as tool for writing an 6809 emulator.
It's design to make memory access through specific memory mapping functions, to simulate
I/O read, Rom, Ram read access during emulation. So it can be use as binary disassembler,
and during emulation. As i wasn't fluent with 6809 assembly at the begining, i have 
included in the instruction database mnemonics explanations. You can easily modify the
code to make them appear on disassembly.

The exe program takes two arguments, the file to disassemble, and a base address to disass
from. Base address is just added to the offset of the begining of the file, so you can
easily disassemble your favorite 'ghost n goblins' romset from the right offset instead of
0000 base address.

Note: The base address parameter is read as hexadecimal format:
dasm6809 gng.rom 1000   will disassemble this rom, from 4096 decimal address !
dasm6809 gng.rom c000   is less confusing :-)

If your archive size is >65536 bytes, the disassembler will complain that its to wide
for 6809 cpu address width.

Feel free to use my code as long as you give credit and don't make business with it.
If you have comment, question or what you want, drop me a mail :-)

Bruno Vedder

----[BCZ]----------------------
You ll find many other usefull/useless things on the Bruno's Coding Zone:
http://bcz.emu-france.com/
bruno.vedder@emu-france.com