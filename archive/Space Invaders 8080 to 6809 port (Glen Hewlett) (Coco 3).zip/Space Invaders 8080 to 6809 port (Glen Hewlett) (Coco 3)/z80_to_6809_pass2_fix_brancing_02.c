#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

void convert(char line[], char newcode[]);
void getparts(char line[], char first[], char second[]);
int getsingle(char line[], char first[]);

int main(int argc, char* argv[])
{
    FILE *file = NULL;
    char line[256];
    char temp[256];
    char newline[256];
    char lnumber[4000][5];
    int pos, x, found, frts;
    
    if (argc == 2)
       	file = fopen(argv[1], "r");
    else {
        fprintf(stderr, "error: wrong number of arguments\n"
                         "usage: %s textfile\n", argv[0]);
        return 1;
    }
    pos = 0;
    while (fgets(line, sizeof(line), file)) {
        /* note that fgets don't strip the terminating \n, checking its
           presence would allow to handle lines longer that sizeof(line) */
        // remove the line feed at the end of 'line'
        line[strcspn(line, "\n")] = 0;
        if (strlen(line) > 12) {
            strncpy(temp, line+8, 4);
            temp[4] = '\0';
            //            printf("temp=%s\n",temp);
            if ((strcmp(temp,"LBRA") == 0) || (strcmp(temp,"LBNE") == 0) || (strcmp(temp,"LBCC") == 0) || (strcmp(temp,"LBCS") == 0) || (strcmp(temp,"LBEQ") == 0) || (strcmp(temp,"LBSR") == 0) || (strcmp(temp,"LBMI") == 0) || (strcmp(temp,"BEQ ") == 0) || (strcmp(temp,"BNE ") == 0) || (strcmp(temp,"BCS ") == 0)) {
                found = 0;
                //Is jump address a $ = address?
                if (line[16] == '$') {
     //               printf("found $\n");
                    strncpy(temp, line+17, 4);
                    temp[4] = '\0';
       //             printf("temp=%s\n",temp);
                    // Let's see if it's new and if so add it to the bottom of the table
                    for (x = 0; x < pos ; x++) {
                        if (strcmp(temp,lnumber[x]) == 0) {
                            found = 1;
                            x = pos;
                        }
                    }
                    if (found == 0) {
         //               printf("Adding-%s\n",temp);
                        strcpy(lnumber[pos],temp);
                        pos++;
                    }
                    else {
           //             printf("Already in the list\n");
                    }
                }
            }
        }
    }
    pos--;
    fclose(file);
    
//jump table built now run through again and add out jump locations
    if (argc == 2)
       	file = fopen(argv[1], "r");
    else {
        fprintf(stderr, "error: wrong number of arguments\n"
                "usage: %s textfile\n", argv[0]);
        return 1;
    }
    while (fgets(line, sizeof(line), file)) {
        /* note that fgets don't strip the terminating \n, checking its
         presence would allow to handle lines longer that sizeof(line) */
        // remove the line feed at the end of 'line'
        line[strcspn(line, "\n")] = 0;
        if (strlen(line) > 12) {
            strncpy(temp, line+51, 4);
            temp[4] = '\0';
      //      printf("got -%s\n",temp);
            for (x = 0; x < pos ; x++) {
                if (strcmp(temp,lnumber[x]) == 0) {
                    x = pos;
                    strcpy(newline,"L");
                    strcat(newline,temp);
                    strncpy(temp, line+5, strlen(line)-5);
                    temp[strlen(line)-5] = '\0';
                    strcat(newline,temp);
                    strcpy(line,newline);
//                    printf("newline -%s\n",newline);
                }
            }
            
            strncpy(temp, line+8, 4);
            temp[4] = '\0';
//            printf("temp=%s\n",temp);
            if ((strcmp(temp,"LBRA") == 0) || (strcmp(temp,"LBNE") == 0) || (strcmp(temp,"LBCC") == 0) || (strcmp(temp,"LBCS") == 0) || (strcmp(temp,"LBEQ") == 0) || (strcmp(temp,"LBSR") == 0) || (strcmp(temp,"LBMI") == 0) || (strcmp(temp,"BEQ ") == 0) || (strcmp(temp,"BNE ") == 0) || (strcmp(temp,"BCS ") == 0)) {
                found = 0;
  //              printf("found 1 to fix -");
                //Is jump address a $ = address?
                if (line[16] == '$') {
                    strncpy(temp, line+17, 4);
                    temp[4] = '\0';
  //                  printf("%s\n%s\n",line,temp);

                    strncpy(newline, line, 16);
                    newline[16] = '\0';
                    strcat(newline,"L");
                    strncpy(temp, line+17, strlen(line)-17);
                    temp[strlen(line)-17] = '\0';
                    strcat(newline,temp);
                    strcpy(line,newline);
                    
 //                                    printf("%s\n%s\n",line,newline);
                    
                    
                }
            }
        }
        frts = 0;
        if (strlen(line) > 51) {
            strncpy(temp, line+8, 12);
            temp[12] = '\0';
            if ((strcmp(temp,"RTS - If NZ ") == 0)) {
                strcpy(temp,"BEQ");
                frts = 1;
            }
            if ((strcmp(temp,"RTS - If NC ") == 0)) {
                strcpy(temp,"BCS");
                frts = 1;
            }
            if ((strcmp(temp,"RTS - If C i") == 0)) {
                strcpy(temp,"BCC");
                frts = 1;
            }
            if ((strcmp(temp,"RTS - If Z i") == 0)) {
                strcpy(temp,"BNE");
                frts = 1;
            }
            if (frts == 1) {
                strncpy(newline, line, 8);
                newline[8] = '\0';
                strcat(newline,temp);
                strcat(newline,"    >                                  ");
                strncpy(temp, line+50, strlen(line)-50);
                temp[strlen(line)-50] = '\0';
                strcat(newline,temp);
                strcat(newline,"\n");
                strcat(newline,"        RTS");
                strcat(newline,"\n");
                strcat(newline,"!        * Jump here");
                strcpy(line,newline);
            }
        }

        printf("%s\n",line);
    }
    fclose(file);
    return 0;
}
