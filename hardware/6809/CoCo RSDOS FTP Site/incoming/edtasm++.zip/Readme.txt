Hello! I'd like to tell you a story. I used to have a coco 2 with 64k ram.
I also had the EDTASM+ rompak I type in Roger Schrag's Super Patch Program.
Well some one broke in and stoled all my stuff. I went out and got a coco 3
which was a better machine anyway but, I sure missed having edtasm+ super
patch program. I had moved on to msdos 'yuk' until I got my coco 3 emulator
and now I am having fun again!  I got a emulaltor disk of the internet and it
had on it EDITASM+ I thought wow as I started to type in Roger Schrag's Super
Patch Program in I couldn't wait! but, then it wouldn't work! I got to work
and I cracked this hack back into a Super Patch Program again!

Thanks Roger!  I hope you like this one
john.