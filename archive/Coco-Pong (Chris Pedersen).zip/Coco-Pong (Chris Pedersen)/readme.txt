
Coco-Pong

This is my own version of Pong which I wrote in Microsoft Color Basic for my 
~1981 TRS-80 Color Computer I (16K). The attached zip file contains a .wav 
file and a .bas file. Not sure whether you should call the game "Pong" or 
"COCO-PONG" here on the archive. The program is saved as "PONG" and the name 
of the game on the splash screen is "COCO-PONG". Not sure if anyone else has 
submitted a Pong yet, or if one was written for the CoCo. Either way, hope 
you guys like my submission. And BTW, this game was written by myself in 2018,
it is not a classic or anything like that.

Thanks,

Chris Pedersen
chris@topherpedersen.com