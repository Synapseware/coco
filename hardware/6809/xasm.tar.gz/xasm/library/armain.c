
/* armain.c */
#include <stdio.h>
#include "aslib.h"

#define DELETE	-1
#define REPLACE 0

int
main(argc, argv)
char *argv[];
{
	char *p, c;
        struct lfile *lfp;
        int i;
        int arname_is_set = 0;
        char action = 0;

	for (i=1; i<argc; ++i)
	{
		p = argv[i];
		if (*p == '-') {
			c = *(++p);
			switch(c) {
				case 'd': /* delete */
				case 'q': /* quick append */
				case 'r': /* replace */
                                case 'p': /* print contents */
                                   	action = c;
					break;
                                
                                case 'v':
                                   	verb_level = 1;
                                        if ( *(p+1) != '\0' ) {
                                           verb_level = (int)( *(p+1) - '0' );
                                           verb_level = ( (verb_level > 9 ) ? 9 : verb_level );
                                           verb_level = ( (verb_level < 0 ) ? 0 : verb_level );
                                        }
                                        break;

				default:
					usage();
			}
		} else {
                   if ( !arname_is_set ) {
                      	arname = new( strlen(p)+1 );
                        strcpy( arname, p );
                        arname_is_set = 1;                   
                   } else {
                        if (linkp == NULL) {
                                linkp = (struct lfile *)
						new (sizeof (struct lfile));
				lfp = linkp;
			} else {
				lfp->f_flp = (struct lfile *)
                                        	new (sizeof (struct lfile));
				lfp = lfp->f_flp;
			}
			lfp->f_idp = (char *) new (strlen(p)+1);
			strcpy(lfp->f_idp, p);
			lfp->f_type = F_REL;
                   }
                }
        }
        
        if ( !arname_is_set )
           usage();
           
        /* Library verarbeiten */
        if ( verb_level > 0 ) {
           printf( "outputfile: %s \nprocessing files ", arname );
           lfp = linkp;
           while ( lfp ) {
              printf("%s ", lfp->f_idp );
              lfp = lfp->f_flp;
           }
           printf("\nverbosity level %d \n", verb_level );
        }
        
        
        if ( action == 'd' )
           librepl( DELETE );
        else if ( action == 'q' )
           libapp();
        else if ( action == 'r' )
           librepl( REPLACE );
        else if ( action == 'p' )
           libdump();



   	return 0;                
}



VOID
libapp()
{
   FILE * libf;
   int ret;
   int newlib = 0;
   char modname[32];
   
   modname[0] = '\0';
   
   libf = fopen( arname, "r" );
   if ( !libf )
      newlib = 1;
   else 
      fclose( libf );
   
   libf = fopen( arname, "a" );
   if ( !libf ) {
      printf( "cannot open %s\n", arname );
      exit(1);
   }
   
   if ( newlib )
       fprintf( libf, "Lib %s\n", arname );

   filep = linkp;
   
   while ( ret = getline() ) {
      if ( ret == 2 && *modname )
              fprintf( libf, "L1 %s\n", modname );
      if ( ret == 2 ) {
              strcpy( modname, cfp->f_idp );
              fprintf( libf, "L0 %s\n", modname );
      }
      fprintf( libf, "%s\n", ib );
   }

   fprintf( libf, "L1 %s\n", modname );   
   fclose( libf );
   
}


VOID librepl( int delete )
{
   struct lfile *flp;
   
   if ( !linkp ) 
      usage();
      
   while ( linkp ) {
           librepl( delete );
           flp = linkp->f_flp;
           linkp = linkp->f_flp;
           free ( flp->f_idp );
           free ( flp );
   }
}


VOID
librepl2( int delete )
{
   FILE * libf, *newf;
   int ret;
   char modname[NCPS];
   char newb[NINPUT];
   char c; 
   struct lfile * oldlinkp;
   
   oldlinkp = linkp;
   linkp = (struct lfile *)new( sizeof ( struct lfile ) );
   linkp->f_idp = (char *)new( strlen( arname) +1 );
   strcpy( linkp->f_idp, arname );
   linkp->f_type = F_REL;
   filep = linkp;
      
   modname[0] = '\0';

   libf = fopen( "00tmp.a", "w" );
   if ( !libf ) {
      printf( "cannot open %s\n", arname );
      exit(1);
   }
   
   newf = fopen( oldlinkp->f_idp, "r" );
   if ( !newf ) {
      printf( "cannot open %s\n", arname );
      exit(1);
   }


   while ( getline() ) {
           ip = ib;
           c = getnb();
           switch ( c ) {
              case 'L':
                      c = getnb();
                      if ( c == '0' ) {
                              getid( modname, -1 );
                              
                              if ( !strcmp( modname, oldlinkp->f_idp )) {
                                  if ( !delete ) {
                                      fprintf( libf, "%s\n", ib );		/* L0 .. */
                                      
                                      while ( fgets( newb, NINPUT-1, newf )) {
                                          int i;
                                          i = strlen( newb ) - 1;
                                          if ( newb[i] == '\n' )
                                              newb[i] = 0;
                                          fprintf( libf, "%s\n", newb );
                                      }
                                  }
                                         
                                  while ( getline() )
                                      if ( ib[1] == '1' )
                                          break;
                                          
                                  if ( !delete ) {           
                                      fprintf( libf, "%s\n", ib );		/* L1 .. */
                                  }
                              }
                              else 
                                      fprintf( libf, "%s\n", ib );		/* L0 .. */
                              break;
                      }
                      fprintf( libf, "%s\n", ib );
                      break;
              default:
                      fprintf( libf, "%s\n", ib );
                      break;
           }
   }
   
   fclose( libf );
   fclose( newf );
   
   sprintf( newb, "rm %s", arname );
   system ( newb );
   sprintf( newb, "mv 00tmp.a %s", arname );
   system ( newb );
              
}

VOID
libdump()
{
   struct lfile * oldlinkp;
   char modname[32];
   char area[32];
   char label[32];
   char type, c;
   unsigned int val, val2;
   
   oldlinkp = linkp;
   
   linkp = (struct lfile *)new( sizeof ( struct lfile ) );
   linkp->f_idp = (char *)new( strlen( arname) +1 );
   strcpy( linkp->f_idp, arname );
   linkp->f_type = F_REL;
   filep = linkp;
   
   modname[0] = '\0';
   area[0] = '\0';
   label[0] = '\0';
   
   while ( getline() ) {
      ip = ib;
      c = getnb();
      switch ( c ) {
         case 'S': 
            	 sscanf( ib, "S %s %cef%x", label, &type, &val );
                 if ( type == 'D' )
                    printf( "%04x % 16s %s\n", val & 0x0ffff, area, label );
            	 else
                    printf( "     % 16s %s\n", "(undefined)", label );
                 break;
         case 'A':
            	 sscanf( ib, "A %s size %x flags %x\n", area, &val, &val2 );
                 break;
         case 'H':
            	 break;
         case 'M':
                 break;
         case 'L':
            	 c = getnb();
                 if ( c == '0' ) {
                    getid( modname, -1 );
                    printf( "\n%s:\n", modname );
                 }
                 break;
         default:
      }
   }
   
   free ( linkp->f_idp );
   free ( linkp );
   linkp = oldlinkp;

}


/* Gebrauchsanweisung, keep up to date */

char *usetxt[] = {
	"Usage: {-Option} archive [files]",
	"  -q   quick append at the end",
	"  -r	replace file(s)",
	"  -d   delete file(s)",
	"  -p   print contents of archive",
	"",
	0
};

VOID
usage()
{
	register char	**dp;

	fprintf(stderr, "\nASxxxx Library Manager %s\n\n", VERSION);
	for (dp = usetxt; *dp; dp++)
		fprintf(stderr, "%s\n", *dp);
	exit(1);
}

FILE *
afile(fn, ft, wf)
char *fn;
char *ft;
{
	FILE *fp;
	char fb[FILSPC];

	strcpy(fb, fn);
	if (ft != NULL)
	{
		strcat(fb, ".");
		strcat(fb, ft);
	}
	if ((fp = fopen(fb, wf?"w":"r")) == NULL) {
		fprintf(stderr, "%s: cannot %s.\n", fb, wf?"create":"open");
		exit(1);
	}
	return (fp);
}

