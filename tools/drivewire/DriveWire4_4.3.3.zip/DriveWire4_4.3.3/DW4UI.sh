#!/bin/sh

java -XX:+UseConcMarkSweepGC -jar DW4UI.jar --backup &
