3D Deathchase 18/03/2009.
=========================
3D Deathchase (c) 2009 James McKay.

3D Deathchase for the Tandy Color Computer / Dragon has been made available as a free download to the general public.  Copyright remains with the original author(s).  Your rights are limited to downloading it, playing it on an emulator (or the original hardware) and enjoying it!  Anything else will require permission.  ;)

Special thanks go to Richard Wilson for the Amstrad CPC disassembly and the members of the forums mentioned further down for assistance and testing.  Also to the few who continue to put CoCo and Dragon technical information on their webpages and to Kryten_Droid for sending me his Color Computer technical reference manual.

This game is a conversion of the original by Mervyn J. Estcourt (c) 1983.  Sadly, he could not be contacted to ask how he felt about the making of this conversion.  If anyone knows how to contact him, I'd be grateful for the information.


The Game
========
3D Deathchase is an action game designed for the Tandy Color Computer range as well as the Dragon range of computers and (possibly) the Prologica CP-400.

It requires at least 16K of RAM, so should run on everything except the very early 4K models.


Included are CAS/WAV files and a DSK file.  The CAS files will load into any Tandy/Dragon emulator that supports cassette loading and the DSK file will work on most Tandy emulators.

To use the DSK file, "insert" it into the emulator and type RUN"D and then press RETURN.
To use the CAS/WAV file, "insert" it into the emulator and type CLOADM and then press RETURN.


Storyline
=========
THE STORY SO FAR

It is 2501, 100 years after the Great War. The North American continent is
ruled by mighty warlords in constant conflict over forest territory. You
are one of the elite mercenaries, Riders of the Big Bikes. It's a quick
way to get rich - and a quicker way to die. You patrol your forest below and
above the Arctic circle, chasing enemy Riders and destroying them with your guided photon 
bolts for $1000 a time. You may find helicopters and tanks too - your 
masters reward you particularly well if you destroy these.

You can only fire at the other Riders when at top speed and cannot hit 
them unless you are close enough - your range indicator will flash when 
you are in range and your purse increases as long as your are in such
hot pursuit.

It is said that the greatest reward is kept for the Rider who can 
penetrate 8 sectors - you will need every ounce of skill to find out...


Gameplay
========
Use keys 1 and 2 to choose the controls and start the game.  1 selects keyboard (cursor keys + space) and 2 selects joystick (right port).  Alternatively, you can press fire.

You can return to the Controls screen at any time by pressing RESET, this is effectively the "quit" button.

UDLR - Accelerate, decelerate, move left or right.
Fire - Fire photon bolts.

Each stage has two bikes to destroy plus a special object (a helicopter or a tank).  Destroying both bikes will take you onto the next phase.


Saving to a real machine
========================
I am not sure how to copy the DSK to a real disk at the moment (I don't have access to a disk drive), so I may post that on my website if someone is kind enough to help out.

If you do not have the WAV files, convert the CAS file to a real cassette I recommend that you download Dragon Convert and use the command line utility "DCEXE40.EXE".


In a command window, type:

DCEXE40 /2 GAMES\DCHS.CAS

(This will create DCHS.WAV).

It is also possible to use Jeff Vavasour's CASOUT utility, but DCEXE produces a longer file that may be more reliable.

Once you have the WAV file, you just need to connect the "audio out" of your soundcard to the "MIC" socket of your cassette recorder, press record (wait until the tape leader has passed) and then play the WAV using something like Windows Media Player (or equivalent).

When you have the tape, rewind, connect the cassette recorder to your Tandy/Dragon, type CLOADM and press PLAY.  (The tape takes about 3 minutes to load).

It is also possible to connect the "audio out" of your soundcard directly to the cassette cable of your Tandy/Dragon, bypassing the cassette recorder altogether.  This is at your own risk, do take care, and make sure the Tandy/Dragon is switched off before you connect or disconnect and cables.  I have done this a few times without problems, but I always make sure everything is switched off before I connect/disconnect the cables.  Also note that using "direct connection" isn't a good judge of the stability of the loader.


Just in case...
===============
Several of the detection routines have not been fully tested.  The only real hardware that has been used is a PAL Tandy Color Computer 2 (64K) and some CoCo 3s.  If you could try this on any other hardware and report the results to me, I would be very grateful indeed!

The PAL/NTSC detection is particularly worth testing, also testing on Dragon machines, early CoCos (must have 16K+), the Prologica CP-400 and the Tano Dragon.  Additionally, when using two players on keyboard - do the keys clash with each other due to the keyboard matrix?

Finally, I'd like to hear any feedback on the game itself, whether it's bugs or an assessment of the gameplay.


Look for contact details at:
http://www.indigobanquet.adsl24.co.uk/coco/deathchase/deathchase.htm

I'll also be hanging out at the CoCo 3 forums:
http://www.coco3.com/forums

And at the Dragon Archive forums: (registration required)
http://www.dragon-archive.co.uk/index.php


NOTE: In the (unlikely) event that the m/c loader doesn't work (CAS), you can do the following to bypass it:

PCLEAR 1 (ignore this if your machine has the early Color Basic)
CLEAR 256,6656
SKIPF
CLOADM
CLOADM
EXEC

If the disk loader reports a SN (syntax) error then try typing RUN to see if it will work the second time around (I have seen this happen in one version of MESS).


Features
========
* 100% machine code!  All the old games said that.  ;)
* Runs on both PAL and NTSC machines.
* Runs on both Tandy and Dragon machines (CAS version).
* Autorunning loader (CAS version).
* Some (basic) sound.
* Uses up nearly all 15.5K of the 16K available!
* 8 sectors, in forest and arctic form.
