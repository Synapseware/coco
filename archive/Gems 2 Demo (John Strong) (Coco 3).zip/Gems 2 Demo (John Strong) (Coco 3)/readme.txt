
Gems 2 game demo

Requires mouse or joystick.
R selects RGB, C selects Composite.

For purchase options contact johnstrong@hotmail.com
