#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

void convert(char line[], char newcode[]);
void getparts(char line[], char first[], char second[]);
int getsingle(char line[], char first[]);

int main(int argc, char* argv[])
{
    FILE *file = NULL;
    char line[256];
    char newcode[1024];
    int lnumber;
    
    if (argc == 2)
       	file = fopen(argv[1], "r");
    else {
        fprintf(stderr, "error: wrong number of arguments\n"
                         "usage: %s textfile\n", argv[0]);
        return 1;
    }
    
    lnumber = 1;
    while (fgets(line, sizeof(line), file)) {
        /* note that fgets don't strip the terminating \n, checking its
           presence would allow to handle lines longer that sizeof(line) */
        // remove the line feed at the end of 'line'
        line[strcspn(line, "\n")] = 0;
        convert(line, newcode);
//          printf("%s\n%s\n", line, newcode);
        printf("%s\n", newcode);
        lnumber++;
    }
    /* may check feof here to make a difference between eof and io failure -- network
       timeout for instance */

    fclose(file);

    return 0;
}

void getparts(char line[], char first[], char second[])
{
    int ret,x,pos,pos2;
    
    // Get first part - before comma
    ret = 0;
    for (x = 30; x < 50; x++) {
        if (line[x] == ',') {
            ret = 1;
            pos = x;
        }
    }
    if (ret == 1) {
        strncpy(first, line+30, pos-30);
        first[pos-30] = '\0';
    }
    // get second part - after comma
    ret = 0;
    for (x = pos; x < 50; x++) {
        if (line[x] == ' ') {
            ret = 1;
            pos2 = x;
            x = 50;
        }
    }
    if (ret == 1) {
        strncpy(second, line+pos+1, pos2-pos-1);
        second[pos2-pos-1] = '\0';
    }
}
/*  get single value return with value in first and point indicates:
 0 - register
 1 - points to register mem location [register]
 2 - memory location - $1e00
 3 - points to memory location [$1e00]
 */
int getsingle(char line[], char first[])
{
    int ret,x,pos,test = 0;
    char temp[256];
    int point = 0;
    
    // Get first part - before comma
    ret = 0;
    for (x = 30; x < 50; x++) {
        if (line[x] == ' ') {
            ret = 1;
            pos = x;
            x = 50;
        }
    }
    if (ret == 1) {
        strncpy(first, line+30, pos-30);
        first[pos-30] = '\0';
    }
    if (first[0] == '$') {
        point = 2;
        test = 1;
    }
    if (first[0] == '(') {
        point = 3;
        test = 1;
    }
    if ((strlen(first) == 1) || (strlen(first) == 2)) {
        point = 0;
        test = 1;
        if (ret == 1) {
            strncpy(first, line+30, pos-30);
            first[pos-30] = '\0';
        }
    }
    else {
        strncpy(temp, first, 2);
        temp[2] = '\0';
        // Test for (HL)
        if ((strncmp(temp, "(H" ,2) == 0)) {
            point = 1;
            test = 1;
            strcpy(first, "HL");
        }
    }
    return point;
}

void convert(char line[], char newcode[])
{
    int ret,x,pos,comma;
    int startdata, enddata;
    char address[1024];
    char temp[1024],temp2[1024];
    char z80[256];
    char comment[256] = "";
    char m6809[1024] = "";
    char fcb[256] = "";
    
    if (strcmp(line, "\n") != 0) {
        strcpy(newcode, "");
    }
    ret = strncmp(line, ";", 1);
    if (ret == 0){
        // find comment
        ret = 0;
        for (x = 0; x < strlen(line); x++) {
            if (line[x] == ';') {
                ret = 1;
                pos = x;
            }
        }
        if (ret == 1) {
            strncpy(comment, line+pos, strlen(line)-pos);
            comment[strlen(line)-pos] = '\0';
        }
        strcpy(newcode, comment);
    }
    // line of code
    if ((isdigit(line[0]) == 0)) {
        strcpy(newcode, line);
    }
    else
    {
        strncpy(address, line, 5);
        address[5] = '\0';
        strcpy(temp2,";");
        strcat(temp2,address);
        strcpy(address,temp2);
        strcat (address,"\n");
        strncpy(temp, line, 4);
        temp[4] = '\0';
        
        // find data
        startdata = 0;
        enddata = 0;
        
        // find comment
        ret = 0;
        for (x = 0; x < strlen(line); x++) {
            if (line[x] == ';') {
                ret = 1;
                pos = x;
            }
        }
        if (ret == 1) {
            enddata = pos;
            for (x = pos - 1 ; x > 1 ; x--)
                if (line[x] != ' ') {
                    enddata = x;
                    x = 1;
                }
        }
        else {
            enddata = strlen(line);
        }
        x = 5;
//        strcpy(m6809,"ORG      $");
        strcpy(m6809,"FCB      ");
//        strcat(m6809,temp);
//        strcat(m6809,"\n");
        comma = 0;
        while(x < enddata) {
            if (line[x] == ' ') {
                strncpy(temp, line+x+1, 2);
                temp[2] = '\0';
                if (comma == 1) {
                    strcpy(fcb,",$");
                }
                else {
                    comma = 1;
                    strcpy(fcb,"$");
                }
//                strcat(fcb,"             FCB      $");
                strcat(fcb,temp);
//                strcat(fcb,",");
                strcat(m6809,fcb);
                x =x + 3;
            }
        }
//        strcat(m6809,"\n");
        if (ret == 1) {
            strcpy(temp,m6809);
//            strncpy(temp, m6809, strlen(m6809)-1);
//            temp[strlen(m6809)-1] = '\0';
            strcat(temp,"                  ");
            strcpy(m6809,temp);
        }

        
        // find comment
        ret = 0;
        for (x = 0; x < strlen(line); x++) {
            if (line[x] == ';') {
                ret = 1;
                pos = x;
            }
        }
        if (ret == 1) {
            strncpy(comment, line+pos, strlen(line)-pos);
            comment[strlen(line)-pos] = '\0';
        }
        
        if ((strncmp(m6809, "UNKNOWN" ,7) == 0)) {
            printf("error: unknown instruction -%s-\n"
                "address: %s\n"
                    "line: %s\n", z80, address,line);
            exit(-2);
        }
        
        strcat(address,"        ");
        strcat(address,m6809);
        strcat(address,comment);
        strcat(newcode,address);
        
    }
}

