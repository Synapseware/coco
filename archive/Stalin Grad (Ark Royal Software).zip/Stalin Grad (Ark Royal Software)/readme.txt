
Stalin Grad by Ark Royal Software

To run the game:

- Type RUN"RUSSIA" and press ENTER
- Press the RESET button until the screen is blue, then press ENTER
- Press any key then choose your skill level and press ENTER
- At the OK prompt, type RUN and press ENTER
- Enjoy!
