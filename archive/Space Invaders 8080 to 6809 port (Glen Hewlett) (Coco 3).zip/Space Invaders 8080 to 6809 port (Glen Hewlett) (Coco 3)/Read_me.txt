Space Invaders Original 8080 code translated to 6809 Code for the TRS-80 Color Computer 3

Use LWASM to compile the Space Invaders assembly code into CoCo Binary files using:

$ lwasm -9bl -p cd -oSI.BIN Space_Invaders_001.asm > listing.txt


There are some simple 'C' programs here to help others who may want to port Z80 code to 6809
The main program is:
z80_to_6809_09.c
z80_to_6809_pass2_fix_brancing_02.c

Compile with:
$ gcc -Wall z80_to_6809_09.c -o z_to_9_Code
$ gcc -Wall z80_to_6809_pass2_fix_brancing_02.c -o z_to_9_Pass2

Use them on the Computer Archeology's disassembled code (http://computerarcheology.com/) with:
$ ./z_to_9_Code SI.asm > 6809_out.asm
$ ./z_to_9_Pass2 6809_out.asm > SI_6809_001.asm


Another program to help with the data sections of the Space Invaders disassembly:
z80_to_6809_Data_06.c
$ gcc -Wall z80_to_6809_Data_06.c -o z_Data_to_9_Data

$ ./z_Data_to_9_Data SI_Data.asm > SI_6809_Data.asm

Cheers,
Glen Hewlett