
Gates of Delirium disks
-----------------------

gofdplyr.dsk - Gates Original Game Disk in DMK Format
gofdgame.dsk - Gates Original Player disk in DSK Format
gatescrk.dsk - Gates Game disk with Copy Protection removed
gatesfix.dsk - Gates Game disk with Copy Protection removed, patched to work 
               with Jeff Vavasour's Coco 2 and 3 emulators
gatescht.dsk - Gates Game disk with Copy Protection removed, patched as above, 
               with integrated cheat module: 

Cheat Module Quick Start
------------------------

Press ! at command prompt in game, screen will switch to 32x16 text screen 
allowing change of various game parameters.  

Press ! to exit character stat mod screen back to the first screen.  

Press ! again to exit back to game.  Enter values in Hex.

Coco 3 only.
