There are two versions on the disk, RAM6809.BIN for a 6809 Coco3 system and RAM6309.BIN for a 6309 Coco3. Both will require 512K RAM to be installed in the Coco3.
Select the version desired and rename to RAMDISK.BIN.

SYNTAX: LOADM"RAMDISK" Don't EXEC but there won't be any damage if you do.
Use the BACKUP, COPY, or DSKINI commands in the normal fashion. The contents of the RAM disk will survive a hard RESET but will be lost if the Coco is turned off.
You will need to enter DRIVEON or DRIVEOFF 2 before the DSKINI command will work with the RAM disk.