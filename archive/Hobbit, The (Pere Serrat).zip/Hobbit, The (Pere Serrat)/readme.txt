
This is the DEFINITIVE FINAL version for The Hobbit (v16f9).

To play the game:

H1X for normal speed (0,89MHz)
H2X for double speed (1,78MHz)
HIMG for normal speed, but loading images at 2x

Besides, to make things easier to CoCo users with twin floppies or with CoCo-SDC, 
I have added some code so that the program detects if there is a disk on the 'other' 
drive and if it is the case, it will use that drive to search for the images.
That way we avoid the annoying change of disks on the Smaug screen.

And, MOST IMPORTANT, STOP when you get to the Smaug screen. In this moment you have 
to change the disk in drive 0 and put there the one with the images.

The program disk can be used in drive 1 to save games or use another disk. Only then 
we should press a key to go on. Obviously, if you want to play text only mode you 
don't need that disk change procedure.

To see the images collection
Put the program disk in drive 0 and the images disk in drive 1
Enter: RUN"DEMOGFX" and follow instructions

As a reminder, these commands-combinations can make life easier to players
- QUIT and then Break returns to the BASIC Interpreter
- Shift+Left Arrow erases the written command
- the @ sign repeats last command

This version is compatible with Drivewire.

Pere Serrat
