About DRWHO.DSK:

This game originally came on cassette. It included a music file, "Country Roads", and
the BASIC game. I hope Larry is okay with me uploading this.

CTRYROAD.BIN
DRWHO.BAS

To run the game type:

RUN"RUNME"

The game will play the music file while the instructions are displayed, so you have to
sit there for a few minutes listening to the music with no way to abort.

The user interface was not very good or intuitive but if you can get past that, the
game itself was actually quite good.

---

Also on the disk is an old Dr. Who demo I (Allen Huffman) put together. It has a BASIC
loader, then a file that is the logo, and another that is the theme song I tried to
recreate (by ear) in Musica 2. The only reference of the song I had at the time was a
cassette recording I made from the TV speaker :)

Someone can clean up these notes and the files, if they wish.

        -- Allen (3/5/2017)
