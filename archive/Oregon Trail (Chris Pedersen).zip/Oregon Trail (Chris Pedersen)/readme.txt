
Oregon Trail

This is the 1971/1978 version of Oregon Trail as published in the May/June 
Issue of Creative Computing Magazine. I wanted to be able to play the game 
on my 16k CoCo 1 with standard Color BASIC, so I had to do quite a bit of 
modification to get the game to work. Most notably, the original version as 
published was 20 kilobytes in size, so I had to whittle at the program until 
I could get it down to 14k. Also, the original version of the game asked 
users to type in words which sounded like gunshots in order to hunt. Hunting 
success was determined by how fast the player could type in the word. However, 
standard Color BASIC did not include a TIMER function, so I had to change the 
hunting subroutine so that success is determined entirely by change via random 
number generation. But other than these necessary changes, I tried to stay as 
true to the original game and source code as possibly. For example, users still 
have to type in a word that sounds like a gunshot to hunt, just the outcome is 
no longer determine by how fast the word is entered. Anyway, I hope you like my 
submission. I think it's pretty neat. Also, while this source code is based on 
code from the 70's, my version for the CoCo 1 was written in 2018 and is not 
classic in any way. (zip file contains .wav and .bas)

Thanks,

Chris Pedersen
chris@topherpedersen.com
