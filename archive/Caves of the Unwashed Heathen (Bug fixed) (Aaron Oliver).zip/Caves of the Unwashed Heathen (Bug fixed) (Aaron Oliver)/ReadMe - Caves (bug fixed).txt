Caves of the Unwashed Heathen
(by Paul Shoemaker)

With bug fixes by Mr. Reaper (Aaron Oliver) www.tinyvast.com


This obscure, simple little D&D-inspired game is really pretty cool, 
and it's impressive that it was written in BASIC.
But upon trying to play it, I kept encountering various issues, 
so I fixed many of them.


Quick notes:
------------
You really should run this game from your Drive 0. 
It always looks on Drive 0 to see the list of characters to load....

Also, the game only accepts UPPER CASE input in some places. 
This should be the default in most CoCo emulators, but certain settings may
result in lower case being used, causing the game to seem unresponsive.

To load this in the CoCo 3 emulator Vcc 1.42, just go through the menus:
Cartridge -> FD-502 Drive 0 -> Insert -> Caves (Coco 3).dsk

If you lose the ability to load disk files (because you loaded other Cartridges),
then just go to Cartridges -> Load Cart -> fd502.dll (included with Vcc)

And this game was designed for Composite screens, so colors will be wrong unless you set:
Configureation -> Display -> Monitor Type -> Composite
(or use F6 to toggle it)


After loading the .dsk file, just type:

RUN "RUNME"

------------ 



It's hard to find much information about this game, other than this old archived page:

http://web.archive.org/web/19990508175213/http://pages.prodigy.net:80/paulshoe/PAULS.HTM

The author seems to have dropped off the face of the internet. 



There is also this other guy who ported the game to the MC-10:

http://jimgerrie.blogspot.com/2017/03/retrochallenge-2017-caves-of-unwashed.html


The game seems to come in two versions: one for the CoCo 2, and one for CoCo 3.

What's the difference?

Well, the CoCo 2 version draws everything with BASIC code, which is pretty slow.
It runs more slowly in general on a CoCo 2 emulator (XRoar). Running it on a CoCo 3
emulator (Vcc 1.42) results in faster drawing and movement, but somehow it seems the 
text prints more slowly than on a CoCo 2 emulator.... and the colors will be a bit off.


The CoCo 3 version uses some different color modes, and draws things in a darker palette.
This causes it to first draw the monsters in the altered palette, then shift them correctly.  
It also uses binary files to draw a few of the main screens (which is instant), but it 
seems to cut off the bottom line of those large images. 

I assume the CoCo 3 version was more up-to-date -- there was a code formatting problem in
the CoCo 2 version which caused an error if you used the Sleep spell, but this was corrected
in the CoCo 3 version (and I fixed it in the CoCo 2 one). So the CoCo 3 version is probably
the one you want to play... unless you can only use a CoCo 2 emulator for some reason. (The
CoCo 3 emulator Vcc 1.42 is really quite simple to use...). I fixed some of the common issues
in the CoCo 2 version, but I did not extensively test that, so there could be other issues. 


Since the game runs quite a bit faster on a CoCo 3 emulator, I slowed down the default delay
for printing text information (it was a hassle to alter it every time you enter the dungeon).
And I made it clear that you were altering the "Delay" and not the "Speed" when you change it.

One big difference with the CoCo 3 version is that it automatically creates a Ram Disk when
you try to run it using the default "RUNME" file. That's not very helpful in an emulator,
and it creates a problem with permanently saving your character (Ram Disk vanishes at power off).
I put in some code to allow you to step around that Ram Disk option, and cleaned up some other 
things with how the game starts, like putting in a proper random seed number so you don't get 
the same sets of stats every time you play.

I also made it more clear how to save your character (select option 4 in the Inn).
After Saving, I give you the option of Quitting the game or continuing.

I changed the color of the position indicator on the map;  with the altered palette, it
was way too dark, and blended in with the walls. I also added a level indicator to the map.

I fixed an issue where if you tried to load the default char.dat file, the game would 
choke badly and leave the files in a state that would just keep choking when you restarted.
It should be fine to load the char.dat character now. It will load the last character that 
was played (which will be MY character, if you haven't played one of your own -- and no, I 
did not cheat to make that character!). Though, if you haven't played any other character, 
it will error if you try to save.
The actual fix would be to NOT show that temporary character file as available to load...  but
I'm not going into the code that deep to fix everything. I just wanted the game to be playable.
Also, never create a character named "char" or you will have serious problems!

Finally, there was an incomplete/corrupt level 5 map which would cause an error when you tried 
to  exit level 4. But there is an exit on level 4, so there needs to be a level 5, or you'd get
a different kind of error when you exit.... So I made a new level 5 (it's just a small END map
with lots of loot) using the nice MAPMAKER program that is included on the dsk. And it seems
the loot you can find on level 5 is pretty nice (I find a +3 items down there!). 

If you make it down that far, and kill the dragon that roams around level 4-5, you can say you
won the game. There is no other end to the game. 

But you can go all the way up to character level 12, if you really want to grind a lot:

Level    XP   Spells
-----------------------     
 1        0   1
 2    1,500   2
 3    3,000   2/1
 4    6,000   2/2
 5   12,000   2/2/1
 6   25,000   2/2/2
 7   50,000   3/2/2/1 (there aren't actually any level 4 spells in the game)
 8  100,000           (I didn't make it past that)
 9  200,000 
10  300,000 
11  400,000 
12  500,000 

