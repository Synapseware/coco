To run, type LOADM"MAUI" and the game will auto execute.
Type EXEC &H1E8 if the game doesn't start automatically.
