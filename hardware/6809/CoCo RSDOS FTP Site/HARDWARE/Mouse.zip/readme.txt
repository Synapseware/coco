Mouse 2.0 for the Radio Shack Color Computer 1,2 & 3.

This group of source, program and data files are copyright 1986, 1997 by Steve Bjork,
All rights reserved.  You may freely use these copyrighted files for personal use only. The copyrighted files can not be sold or marketed with the written consent of Steve Bjork.

This group of files make the Mouse 2.0 system.  The "Mouse.bin" is a simple GUI program with a driver for the joystick (and Hi-res) for input and hi-res screen drive for output.  The "Lines' and "DiskTime" programs are short demos of what the Mouse 2.0 system can do.

Mouse1 to Mouse6 are source code files for Mouse.bin.

CurMak is a cursor making program.

For more info check the pages of Rainbow Mag in 1986 for the 3 part write up on the mouse 2.0 system.

Upload by Steve Bjork

stevebjork@earthlink.net